from PyQt5.QtGui import QRegularExpressionValidator, QStandardItemModel, QStandardItem
from PyQt5.QtCore import QRegularExpression, Qt
from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtSql import QSqlDatabase, QSqlQuery, QSqlQueryModel

from login import LoginWindow
from register import RegisterWindow
from customerpanel import CustomerWindow
from contact import ContactWindow
from order import OrderWindow
import pyodbc
import re
from datetime import datetime
from connection import get_connection

conn = get_connection()
cursor = conn.cursor()


class Controller:
    def __init__(self):
        self.row = None
        self.general_id = None
        self.pattern = re.compile(r'^.{3,}$')
        self.login = LoginWindow()
        self.register = RegisterWindow()
        self.customer = CustomerWindow()
        self.contact = ContactWindow()
        self.courier = OrderWindow()
        #Courier panel codes ------
        # TableView ayarları
        self.courier.ui.tblOrders.setSelectionBehavior(self.courier.ui.tblOrders.SelectRows)
        self.courier.ui.tblOrders.setSelectionMode(self.courier.ui.tblOrders.SingleSelection)
        self.courier.ui.tblOrders.setEditTriggers(self.courier.ui.tblOrders.NoEditTriggers)

        # Model
        self.model = QSqlQueryModel(self.courier)
        self.courier.ui.tblOrders.setModel(self.model)

        # Butonlar
        self.courier.ui.btnRefresh.clicked.connect(self.load_orders)
        self.courier.ui.btnTakeOrder.clicked.connect(self.take_selected_order)
        self.courier.ui.btnDeliverOrder.clicked.connect(self.deliver_selected_order)
        # ------


        #Contact panel codes
        self.contact.ui.pushButton_Send.clicked.connect(self.send_feedback)
        self.contact.ui.pushButton_Back.clicked.connect(self.back_to_customer)
        self.customer.ui.comboBox_City.currentIndexChanged.connect(self.list_districts)
        #Customer panel codes
        self.customer.ui.pushButton_Refresh.clicked.connect(self.refresh_tables)
        self.customer.ui.pushButton_Order.clicked.connect(self.give_order)
        self.customer.ui.pushButton_Contact.clicked.connect(self.show_contact)
        self.customer.ui.pushButton_Login.clicked.connect(self.back_to_login)
        self.customer.ui.pushButton_Address.clicked.connect(self.add_address)
        # Login panel codes
        self.login.ui.pushButton_Login.clicked.connect(self.sign_in)
        self.login.ui.pushButton_Register.clicked.connect(self.show_register)
       
        # Register panel codes 
        self.register.ui.lineEdit_Fname.setValidator(QRegularExpressionValidator(
            QRegularExpression("^[A-Za-z]*$")
        ))
        self.register.ui.lineEdit_Lname.setValidator(QRegularExpressionValidator(
            QRegularExpression("^[A-Za-z]*$")
        ))
        self.register.ui.lineEdit_Username.setValidator(QRegularExpressionValidator(
            QRegularExpression("^[A-Za-z0-9]*$")
        ))
        
        self.register.ui.lineEdit_Phone.setValidator(QRegularExpressionValidator(
            QRegularExpression("^[0-9]*$")
        ))
        self.register.ui.pushButton_Login.clicked.connect(self.show_login)
        self.register.ui.pushButton_Create.clicked.connect(self.create_account)
    
    # Couier panel functions start -----
    # ---------------- TABLE LOAD ----------------
    def load_orders(self):
        sql = """
        SELECT
            order_id,
            user_id,
            address_id,
            branch_id,
            order_status,
            payment_method,
            total_amount,
            created_at
        FROM orders
        ORDER BY created_at DESC
        """
        self.model.setQuery(sql)

        self.model.setHeaderData(0, Qt.Horizontal, "Sipariş ID")
        self.model.setHeaderData(4, Qt.Horizontal, "Durum")
        self.model.setHeaderData(6, Qt.Horizontal, "Tutar")
        self.model.setHeaderData(7, Qt.Horizontal, "Tarih")

        self.courier.ui.tblOrders.resizeColumnsToContents()

    # ---------------- SELECTED ORDER ----------------
    def get_selected_order_id(self):
        index = self.ui.tblOrders.currentIndex()
        if not index.isValid():
            QMessageBox.warning(self, "Uyarı", "Lütfen bir sipariş seç.")
            return None

        row = index.row()
        return int(self.model.data(self.model.index(row, 0)))

    # ---------------- STATUS UPDATE ----------------
    def update_order_status(self, order_id, status):
        q = QSqlQuery()
        q.prepare("UPDATE orders SET order_status=? WHERE order_id=?")
        q.addBindValue(status)
        q.addBindValue(order_id)

        if not q.exec_():
            QMessageBox.critical(self, "DB Hatası", q.lastError().text())
            return False

        return True

    # ---------------- BUTTON ACTIONS ----------------
    def take_selected_order(self):
        order_id = self.get_selected_order_id()
        if not order_id:
            return

        if self.update_order_status(order_id, "shipped"):
            QMessageBox.information(self, "Başarılı", "Sipariş kuryeye alındı.")
            self.load_orders()

    def deliver_selected_order(self):
        order_id = self.get_selected_order_id()
        if not order_id:
            return

        if self.update_order_status(order_id, "delivered"):
            QMessageBox.information(self, "Başarili", "Sipariş teslim edildi.")
            self.load_orders()

    # Couier panel functions end ------

    #Contact panel functions
    def list_messages(self):
        sql = "SELECT complain_topic, feedback FROM MESSAGES WHERE customer_id = ?"
        try:
            cursor.execute(sql, (self.general_id,))
            
        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.contact, "Database Error", str(e))
            return

        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]  # kolon adları

        model = QStandardItemModel()
        model.setColumnCount(len(columns))
        model.setHorizontalHeaderLabels(columns)

        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                item = QStandardItem("" if value is None else str(value))
                model.setItem(r, c, item)

        self.contact.ui.tableView.setModel(model)
        self.contact.ui.tableView.resizeColumnsToContents()
    
    def send_feedback(self):
        sql = """
        INSERT INTO MESSAGES (customer_id, complain_topic, feedback, created_at)
        VALUES (?, ?, ?, ?)
        """
        time = datetime.now()
        topic = self.contact.ui.lineEdit_Topic.text()
        feedback = self.contact.ui.plainTextEdit_Message.toPlainText()
        data = (self.general_id,topic,feedback,time)

        try:
            cursor.execute(sql, data)
            conn.commit()

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.contact, "Database Error", str(e))


    def back_to_customer(self):
        self.contact.hide()
        self.customer.show()
        

    #Customer panel functions
    def back_to_login(self):
        self.customer.close()
        self.login.show()
    def get_selected_value_by_column_name(self, column_name: str, table_name: str):
        view_name = f"tableView_{table_name}"
        view = getattr(self.customer.ui, view_name, None)

        if view is None:
            return None

        model = view.model()
        selection_model = view.selectionModel()

        if model is None or not selection_model.hasSelection():
            return None

        row = selection_model.selectedRows()[0].row()

        for col in range(model.columnCount()):
            if model.headerData(col, Qt.Horizontal) == column_name:
                return model.index(row, col).data()

        return None
    def list_orders(self):
        sql = """
        SELECT * FROM orders WHERE customer_id = ?
            """
        try:
            print(self.general_id)
            cursor.execute(sql, (self.general_id,))

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return
        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description] 

        model = QStandardItemModel()
        model.setColumnCount(len(columns))
        model.setHorizontalHeaderLabels(columns)

        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                model.setItem(r, c, QStandardItem("" if value is None else str(value)))

        self.customer.ui.tableView_Order.setModel(model)
        self.customer.ui.tableView_Order.resizeColumnsToContents()

    def list_cities(self):
        sql = "SELECT city_id, city_name FROM cities"
        try:
            cursor.execute(sql)

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return

        combo = self.customer.ui.comboBox_City
        combo.clear()

        for city_id, city_name in cursor.fetchall():
            combo.addItem(city_name, city_id)
    def list_districts(self):
        sql = "SELECT district_id, district_name FROM districts WHERE city_id = ?"
        try:
            city_id = self.customer.ui.comboBox_City.currentData()
            cursor.execute(sql,(city_id,))

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return

        combo = self.customer.ui.comboBox_District
        combo.clear()

        for district_id, district_name in cursor.fetchall():
            combo.addItem(district_name, district_id)
    def list_address_types(self):
        combo = self.customer.ui.comboBox_Type
        combo.addItems(["House", "Workplace"])
    def list_products(self):
        sql = "SELECT * FROM PRODUCTS"
        try:
            cursor.execute(sql)

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return

        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description] 

        model = QStandardItemModel()
        model.setColumnCount(len(columns))
        model.setHorizontalHeaderLabels(columns)

        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                item = QStandardItem("" if value is None else str(value))
                model.setItem(r, c, item)

        self.customer.ui.tableView_Product.setModel(model)
        self.customer.ui.tableView_Product.resizeColumnsToContents()
    def list_addresses(self):
        sql = """
        SELECT
            a.address_type        AS address_type,
            c.city_name           AS city_name,
            d.district_name       AS district_name,
            a.address_description AS address_description,
            a.postal_code         AS postal_code
        FROM address a
        JOIN cities c    ON c.city_id = a.city_id
        JOIN districts d ON d.district_id = a.district_id
        WHERE a.customer_id = ?
        ORDER BY a.address_id DESC;
            """
        try:
            print(self.general_id)
            cursor.execute(sql, (self.general_id,))

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return
        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]  # SELECT alias’ları

        model = QStandardItemModel()
        model.setColumnCount(len(columns))
        model.setHorizontalHeaderLabels(columns)

        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                model.setItem(r, c, QStandardItem("" if value is None else str(value)))

        self.customer.ui.tableView_Address.setModel(model)
        self.customer.ui.tableView_Address.resizeColumnsToContents()
    def refresh_tables(self):
        self.list_products()
        self.list_addresses()
        self.list_cities()
        self.list_districts()
        self.list_orders()
    def add_address(self):
        sql = """
            INSERT INTO ADDRESS (customer_id, address_type, city_id, district_id, address_description, postal_code)
            VALUES (?, ?, ?, ?, ?, ?)
            """
        address_type = self.customer.ui.comboBox_Type.currentText()
        city_id = self.customer.ui.comboBox_City.currentData()
        district_id = self.customer.ui.comboBox_District.currentData()
        address_description = self.customer.ui.textEdit_Address.toPlainText()
        postal_code = self.customer.ui.lineEdit_PostalCode.text()
        data = (self.general_id, address_type, city_id, district_id, address_description, postal_code)
        try:
            cursor.execute(sql, data)
            conn.commit()

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return
    def give_order(self):
            available_quantity = self.get_selected_value_by_column_name("quantity","Product")
            quantity = int(self.customer.ui.lineEdit_Quantity.text())
            if quantity > available_quantity:
                QMessageBox.critical(self.customer, "Database Error", "Requested quantity is not present in stock")
                return
            sql = """
            INSERT INTO orders (customer_id, product_id, address_id, order_status, quantity, total_price, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            product_id = self.get_selected_value_by_column_name("product_id","Product")
            address_id = self.get_selected_value_by_column_name("address_id","Address")
            order_status = "Order Placed"
            unit_price = self.get_selected_value_by_column_name("unit_price","Product")
            total_price = quantity * unit_price
            time = datetime.now()
            data = (self.general_id, product_id, address_id, order_status, quantity, total_price, time)

            try:
                cursor.execute(sql, data)
                conn.commit()

            except pyodbc.Error as e:
                conn.rollback()
                QMessageBox.critical(self.customer, "Database Error", str(e))
                return

            
    def show_contact(self):
        self.customer.hide()
        self.contact.show()
        self.list_messages()
    #Login panel functions
    def find_general_id(self,user_id,role_name):
        sql = f"SELECT {role_name}_id FROM {role_name + 's'} WHERE user_id = ?"
        try:
            cursor.execute(sql, (user_id,))
            
        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.login, "Database Error", str(e))
            return
        
        row2 = cursor.fetchone()
        print(row2)
        if row2:
            self.general_id = row2[0] 
        else:
            pass

    def show_register(self):
        self.login.hide()
        self.register.show()

    def show_customer(self):
        self.login.hide()
        self.customer.show()
        self.list_products()
        self.list_addresses()
        self.list_cities()
        self.list_address_types()
        

    def show_customer_representive(self):
        self.login.hide()
        self.customer_representive.show()
        self.list_products()
        self.list_addresses()
        self.list_cities()
        self.list_districts()

    def show_courier(self):
        self.login.hide()
        self.courier.show()
        self.load_orders()

    def show_db_admin(self):
        self.login.hide()
        self.db_admin.show()
        self.list_products()
        self.list_addresses()
        self.list_cities()
        self.list_districts()

    def show_admin(self):
        self.login.hide()
        self.admin.show()
        self.list_products()
        self.list_addresses()
        self.list_cities()
        self.list_districts()

    
    def sign_in(self):
        login_str = self.login.ui.lineEdit_Login.text()
        password = self.login.ui.lineEdit_Password.text()
        data = (login_str, password)
        if password == "" or login_str == "":
            self.login.ui.label_Msg.setText("Blank areas exist.")
            return
        email = "@" in login_str
        if email:
            sql = """
            SELECT *
            FROM users
            WHERE email = ? AND password = ?
            """
            try:
                cursor.execute(sql, data)

            except pyodbc.Error as e:
                conn.rollback()
                QMessageBox.critical(self.login, "Database Error", str(e))
                return
        else:
            sql = """
            SELECT *
            FROM users
            WHERE username = ? AND password = ?
            """
            try:
                cursor.execute(sql, data)

            except pyodbc.Error as e:
                conn.rollback()
                QMessageBox.critical(self.login, "Database Error", str(e))
                return
        row = cursor.fetchone()
        if row:
            role_id = row.role_id
            if role_id == 1:
                self.show_customer()
                self.find_general_id(row.user_id,'customer')
            elif role_id == 2:
                self.show_customer() #customer representive
            elif role_id == 3:
                self.show_courier() #kurye
            elif role_id == 4:
                self.show_customer() #dba
            elif role_id == 5:
                self.show_customer() #admin
        else:
            self.login.ui.label_Msg.setText("Invalid credentials.")
    

    # Register panel functions    
    def is_valid_password(self, pw: str) -> bool:
        return self.pattern.fullmatch(pw) is not None
    def show_login(self):
        self.register.hide()
        self.login.show()
    def create_account(self):
        fname = self.register.ui.lineEdit_Fname.text()
        lname = self.register.ui.lineEdit_Lname.text()
        username = self.register.ui.lineEdit_Username.text()
        email = self.register.ui.lineEdit_Email.text()
        password = self.register.ui.lineEdit_Password.text()
        phone = self.register.ui.lineEdit_Phone.text()
        print(fname)
        if fname == "" or lname == "" or username == "" or email == "" or password == "" or phone == "":
            self.register.ui.label_msg.setText("Blank areas exist.")
            return
        if not "@" in email:
            self.register.ui.label_msg.setText("Invalid e-mail address.")
            return
        if not self.is_valid_password(password):
            self.register.ui.label_msg.setText("Password must be at least 3 characters long.")
            return
        
        sql = """
        INSERT INTO USERS (first_name, last_name, role_id, created_at, username, email, password, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """
        time = datetime.now()
        data = (fname, lname, 1, time, username, email, password, phone)

        ##denemeeee

        try:
            # 1) USERS insert
            cursor.execute("""
                INSERT INTO users (first_name, last_name, role_id, created_at, username, email, password, phone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """, (fname, lname, 1, time, username, email, password, phone))

            # 2) Yeni user_id al
            cursor.execute("SELECT SCOPE_IDENTITY();")
            new_user_id = int(cursor.fetchone()[0])

            # 3) CUSTOMERS insert (role customer ise)
            cursor.execute("INSERT INTO customers (user_id) VALUES (?);", (new_user_id,))

            conn.commit()

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.register, "Database Error", str(e))
            return

        QMessageBox.information(self.register, "Success", "Account created successfully.")
        print("Kayıt eklendi.")
        
        
        #logine don
        #self.show_login()

        print("Kayıt eklendi.")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    controller = Controller()
    controller.login.show()     #Start with login window
    sys.exit(app.exec_())
