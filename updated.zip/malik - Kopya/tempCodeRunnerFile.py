def list_addresses(self):
        sql = """
        SELECT
            a.address_type        AS address_type,
            c.city_name           AS city_name,
            d.district_name       AS district_name,
            a.address_description AS address_description,
            a.postal_code         AS postal_code
        FROM address a
        JOIN cities c    ON c.city_id = a.city_id
        JOIN districts d ON d.district_id = a.district_id
        WHERE a.customer_id = ?
        ORDER BY a.address_id DESC;
            """
        try:
            cursor.execute(sql, (self.general_id,))

        except pyodbc.Error as e:
            conn.rollback()
            QMessageBox.critical(self.customer, "Database Error", str(e))
            return
        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]  # SELECT alias’ları

        model = QStandardItemModel()
        model.setColumnCount(len(columns))
        model.setHorizontalHeaderLabels(columns)

        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                model.setItem(r, c, QStandardItem("" if value is None else str(value)))

        self.customer.ui.tableView_Address.setModel(model)
        self.customer.ui.tableView_Address.resizeColumnsToContents()